# python plot_trajectories.py ./configs/UCY.json ./output/Zara-UCY/draw/eps2e-1/2022_02_19_02_17_28/ --num_trajs=3 --eps=0.2 --name=eps2e-1
# python plot_trajectories.py ./configs/UCY.json ./output/Zara-UCY/draw/pearl/2022_02_10_18_12_16/ --num_trajs=3 --name=pearl
# python plot_trajectories.py ./configs/UCY_MPC.json ./output/Zara-UCY/draw/mpc/2022_02_10_18_12_16/ --num_trajs=1 --mpc_only --name=mpc
python draw.py

