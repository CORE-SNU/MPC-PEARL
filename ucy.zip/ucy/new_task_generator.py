from rlkit.envs.utils.restaurant import Restaurant


restaurant = Restaurant(
    num_tasks=205+200,
    num_tables=5,
    num_people=6,
    table_radii=0.5,
    human_radii=0.25,
    ep_len=80
)

restaurant.generate_more_scenarios()