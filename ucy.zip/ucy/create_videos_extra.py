import numpy as np
from typing import Any, Dict
import pickle
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.animation import FuncAnimation, writers

num_tables = 5
num_people = 6
table_radii = 0.5
human_radii = 0.25
num_trajs = 5
ep_len = 80
lr = 0.25

init_pos = (-4.5, 4.5)
goal_pos = (3.5, -3.5)


begin = 0
end = 25
tasks = range(begin, end)

names = ['mpc', 'pearl', 'eps2e-1', 'eps5e-1', 'eps8e-1', 'eps1e0']
colors = {
    'mpc': 'black',
    'pearl': 'tab:brown',
    'eps2e-1': 'tab:purple',
    'eps5e-1': 'tab:orange',
    'eps8e-1': 'tab:blue',
    'eps1e0': 'tab:red'
}
markers = {name : 'D' if name == 'pearl' or name == 'mpc' else 'o' for name in names}

plt.rcParams['animation.ffmpeg_path'] = '/usr/bin/ffmpeg'
writer = writers['ffmpeg'](fps=5)

# load table configurations
f = open('tables_extra.pkl', 'rb')
tables = pickle.load(f)

# adapted after
for idx in tasks:
    # ==================== single video generation ====================
    fig, ax = plt.subplots()
    ax.set_aspect('equal')
    ax.grid(True)
    ax.set_xlim(-5., 5.)
    ax.set_ylim(-5., 5.)
    ax.set_xlabel(r'$\mathrm{x}$', fontsize=20)
    ax.set_ylabel(r'$\mathrm{y}$', fontsize=20)
    ax.tick_params(labelsize=18)
    plt.scatter(init_pos[0], init_pos[1], color='black', marker='s', s=80, zorder=3)
    plt.annotate('Start', (init_pos[0] + 0.7, init_pos[1] - 0.3), fontsize=20)
    plt.scatter(goal_pos[0], goal_pos[1], color='black', marker='s', s=80, zorder=3)
    plt.annotate('Goal', (goal_pos[0] - 0.3, goal_pos[1] - 1.), fontsize=20)

    # render tables in the restaurant
    table_pos = tables['task{}'.format(idx - begin)]
    for i in range(num_tables):
        x_table = table_pos[2 * i]
        y_table = table_pos[2 * i + 1]
        obstacle = plt.Circle((x_table, y_table),
                              table_radii,
                              color='tab:blue'
                              )
        ax.add_artist(obstacle)

    # ---------------------- read dynamic data -----------------------
    colh: Dict[str, Any] = {}   # collision with human indicator
    colt: Dict[str, Any] = {}   # collision with table indicator
    robot: Dict[str, Any] = {}

    stored_already = False

    for name in names:
        f = open('snapshot_{}_extra.pkl'.format(name), 'rb')
        trajectories = pickle.load(f)
        num_trajs = len(trajectories['task{}'.format(begin)])
        num_trajs = min(num_trajs, 3)
        key = 'task{}'.format(idx)
        obs = 5. * trajectories[key][num_trajs-1]['observations']
        colh[name] = trajectories[key][num_trajs-1]['collisions_human']
        colt[name] = trajectories[key][num_trajs-1]['collisions_table']

        robot[name] = obs[:, :2]
        if not stored_already:
            people = obs[:, 3:3+2*num_people]
            stored_already = True
    # ----------------------------------------------------------------
    lines: Dict[str, Line2D] = {}
    for name in names:
        lines[name] = ax.plot([], [],
                              linestyle='solid',
                              marker=markers[name],
                              color=colors[name],
                              zorder=1,
                              markersize=4,
                              linewidth=1
                              )[0]
    human_obj_list = []
    timestep = ax.text(-5.5, -6.5, '', fontsize=15)

    def func(t):
        # object list initialization
        for obj in list(human_obj_list):
            obj.remove()                # remove rendered object
            human_obj_list.remove(obj)  # remove dummy from the list
        # [1] robot trajectories
        for name in names:
            lines[name].set_data(robot[name][:t, 0], robot[name][:t, 1])    # plot trajectory so far
            if colh[name][t] + colt[name][t] > 0:
                # collision handling
                ax.scatter(robot[name][t, 0], robot[name][t, 1],
                           facecolor='white',
                           edgecolor=colors[name],
                           marker='*', s=240,
                           zorder=2)
        # [2] motions of dynamic obstacles
        for i in range(num_people):
            px, py = people[t, 2*i], people[t, 2*i+1]
            human_obj = ax.add_artist(plt.Circle((px, py), human_radii, color='tab:orange'))
            human_obj_list.append(human_obj)
        timestep.set_text('t = {}'.format(t))   # display current time step within the episode
    # =================================================================
    ani = FuncAnimation(fig=fig, func=func, frames=ep_len - 1)
    fig.tight_layout()
    vid_name = './videos/task{}_after.mp4'.format(idx)
    ani.save(vid_name, writer=writer)
    plt.close('all')


# adapted before
for idx in tasks:
    # ==================== single video generation ====================
    fig, ax = plt.subplots()
    ax.set_aspect('equal')
    ax.grid(True)
    ax.set_xlim(-5., 5.)
    ax.set_ylim(-5., 5.)
    ax.set_xlabel(r'$\mathrm{x}$', fontsize=20)
    ax.set_ylabel(r'$\mathrm{y}$', fontsize=20)
    ax.tick_params(labelsize=18)
    plt.scatter(init_pos[0], init_pos[1], color='black', marker='s', s=80, zorder=3)
    plt.annotate('Start', (init_pos[0] + 0.7, init_pos[1] - 0.3), fontsize=20)
    plt.scatter(goal_pos[0], goal_pos[1], color='black', marker='s', s=80, zorder=3)
    plt.annotate('Goal', (goal_pos[0] - 0.3, goal_pos[1] - 1.), fontsize=20)

    # render tables in the restaurant
    table_pos = tables['task{}'.format(idx - begin)]
    for i in range(num_tables):
        x_table = table_pos[2 * i]
        y_table = table_pos[2 * i + 1]
        obstacle = plt.Circle((x_table, y_table),
                              table_radii,
                              color='tab:blue'
                              )
        ax.add_artist(obstacle)

    # ---------------------- read dynamic data -----------------------
    colh: Dict[str, Any] = {}   # collision with human indicator
    colt: Dict[str, Any] = {}   # collision with table indicator
    robot: Dict[str, Any] = {}

    stored_already = False

    for name in names:
        f = open('snapshot_{}_extra.pkl'.format(name), 'rb')
        trajectories = pickle.load(f)
        key = 'task{}'.format(idx)
        obs = 5. * trajectories[key][0]['observations']
        colh[name] = trajectories[key][0]['collisions_human']
        colt[name] = trajectories[key][0]['collisions_table']

        robot[name] = obs[:, :2]
        if not stored_already:
            people = obs[:, 3:3+2*num_people]
            stored_already = True
    # ----------------------------------------------------------------
    lines: Dict[str, Line2D] = {}
    for name in names:
        lines[name] = ax.plot([], [],
                              linestyle='solid',
                              marker=markers[name],
                              color=colors[name],
                              zorder=1,
                              markersize=4,
                              linewidth=1
                              )[0]
    human_obj_list = []
    timestep = ax.text(-5.5, -6.5, '', fontsize=15)

    def func(t):
        # object list initialization
        for obj in list(human_obj_list):
            obj.remove()                # remove rendered object
            human_obj_list.remove(obj)  # remove dummy from the list
        # [1] robot trajectories
        for name in names:
            lines[name].set_data(robot[name][:t, 0], robot[name][:t, 1])    # plot trajectory so far
            if colh[name][t] + colt[name][t] > 0:
                # collision handling
                ax.scatter(robot[name][t, 0], robot[name][t, 1],
                           facecolor='white',
                           edgecolor=colors[name],
                           marker='*', s=240,
                           zorder=2)
        # [2] motions of dynamic obstacles
        for i in range(num_people):
            px, py = people[t, 2*i], people[t, 2*i+1]
            human_obj = ax.add_artist(plt.Circle((px, py), human_radii, color='tab:orange'))
            human_obj_list.append(human_obj)
        timestep.set_text('t = {}'.format(t))   # display current time step within the episode
    # =================================================================
    ani = FuncAnimation(fig=fig, func=func, frames=ep_len - 1)
    fig.tight_layout()
    vid_name = './videos/task{}_before.mp4'.format(idx)
    ani.save(vid_name, writer=writer)
    plt.close('all')
