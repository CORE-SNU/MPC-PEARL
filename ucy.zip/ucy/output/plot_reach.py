import numpy as np
import matplotlib.pyplot as plt
import sys


filename = sys.argv[1]
filename1 = sys.argv[2]
filename2 = sys.argv[3]
data = np.genfromtxt(filename, delimiter=',')[1:, 39]
data_std = np.genfromtxt(filename, delimiter=',')[1:, 41]
data1 = np.genfromtxt(filename1, delimiter=',')[1:, 39]
data1_std = np.genfromtxt(filename1, delimiter=',')[1:, 41]
data2 = np.genfromtxt(filename2, delimiter=',')[1:, 39]
data2_std = np.genfromtxt(filename2, delimiter=',')[1:, 41]
length1 = data.shape[0]
length2 = data1.shape[0]
length3 = data2.shape[0]

window_width = 50
smooth = np.zeros(length1)
smooth1 = np.zeros(length2)
smooth2 = np.zeros(length3)
# up_b = np.zeros(length2)
# low_b = np.zeros(length2)

for i in range(length1):
    begin = max(i - window_width + 1, 0)
    end = i + 1
    smooth[i] = np.mean(data[begin:end])

for i in range(length2):
    begin = max(i - window_width + 1, 0)
    end = i + 1   
    smooth1[i] = np.mean(data1[begin:end])

for i in range(length3):
    begin = max(i - window_width + 1, 0)
    end = i + 1   
    smooth2[i] = np.mean(data2[begin:end])

plt.plot(data, color='tab:red', label=r'$w_{rad} = 0.5$')
plt.fill_between(np.linspace(0,length1,length1), data+data_std, data-data_std, alpha=0.15, color='tab:red')

plt.plot(data1, color='tab:blue', label=r'$w_{rad} = 1.5$')
plt.fill_between(np.linspace(0,length2,length2), data1+data1_std, data1-data1_std, alpha=0.15, color='tab:blue')

plt.plot(data2, color='tab:green', label=r'$w_{rad} = 3$')
plt.fill_between(np.linspace(0,length3,length3), data2+data2_std, data2-data2_std, alpha=0.15, color='tab:blue')

plt.legend()
plt.xlabel('Episodes')
plt.ylabel('States nearby goal (Test during meta-train)')
plt.xlim(0, max([length1,length2])-1)

plt.xlim(0, length2-1)
plt.grid()

plt.tight_layout()
plt.savefig('result_reach_tmp.png')

plt.clf()
plt.plot(smooth, color='tab:red', label=r'$w_{rad} = 0.5$')
plt.plot(smooth1, color='tab:blue', label=r'$w_{rad} = 1.5$')
plt.plot(smooth2, color='tab:green', label=r'$w_{rad} = 3.0$')

plt.legend()
plt.ylabel('States nearby goal (Test during meta-train)')
plt.xlabel('Episodes')
plt.xlim(0, max([length1,length2])-1)
plt.grid()

plt.tight_layout()
plt.savefig('result_reach_smooth_tmp.png')


