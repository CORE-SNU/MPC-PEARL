import numpy as np
import matplotlib.pyplot as plt
import sys


def moving_average(data, window_sz=50, axis=1):
    dim = data.shape[axis]
    processed = np.zeros(shape=data.shape)
    ndim = data.ndim
    for k in range(dim):
        begin = max(0, k - window_sz + 1)
        end = k + 1
        # this produce [:, ..., k, ..., :] where the location of k is specified by axis
        slc = [slice(None)] * ndim
        slc[axis] = k
        # this produce [:, ..., begin: end, ..., :]
        slc_taken = [slice(None)] * ndim
        slc_taken[axis] = slice(begin, end)
        slc = tuple(slc)
        slc_taken = tuple(slc_taken)
        processed[slc] = np.mean(data[slc_taken], axis=axis)
    return processed


def statistics(data, axis=0):
    mean = np.mean(data, axis=axis, keepdims=False)
    std = np.std(data, axis=axis, keepdims=False)
    low, high = mean - 0.5 * std, mean + 0.5 * std
    return mean, low, high


def main(argv):
    num_results = len(argv) - 1
    data_total = {}
    data_navi = {}
    data_col = {}
    length = []
    for i in range(num_results):
        file_name = argv[i + 1]
        data_total[i] = np.genfromtxt(file_name + '/progress.csv', delimiter=',')[1:, 31]
        data_navi[i] = np.genfromtxt(file_name + '/progress.csv', delimiter=',')[1:, 47]
        data_col[i] = np.genfromtxt(file_name + '/progress.csv', delimiter=',')[1:, 51]
        length.append(data_total[i].shape[0])

    common_length = min(length)
    aggregated_total = np.zeros((num_results, common_length))
    aggregated_navi = np.zeros((num_results, common_length))
    aggregated_col = np.zeros((num_results, common_length))
    for i in range(num_results):
        aggregated_total[i] = data_total[i][:common_length]
        aggregated_navi[i] = data_navi[i][:common_length]
        aggregated_col[i] = data_col[i][:common_length]

    smoothed_total = moving_average(data=aggregated_total, axis=1)
    smoothed_navi = moving_average(data=aggregated_navi, axis=1)
    smoothed_col = moving_average(data=aggregated_col, axis=1)
    mean_total, low_total, high_total = statistics(smoothed_total, axis=0)
    mean_navi, low_navi, high_navi = statistics(smoothed_navi, axis=0)
    mean_col, low_col, high_col = statistics(smoothed_col, axis=0)
    x = np.arange(common_length)


    plt.plot(x, mean_total, label=r'$r = r_n + r_c$', color='tab:blue')
    plt.plot(x, mean_navi, label=r'$r_n$', linestyle='dotted', color='tab:red')
    plt.plot(x, mean_col, label=r'$r_c$', linestyle='dashed', color='tab:purple')
    plt.fill_between(x, low_total, high_total, alpha=0.2, color='tab:blue')
    plt.fill_between(x, low_navi, high_navi, alpha=0.2, color='tab:red')
    plt.fill_between(x, low_col, high_col, alpha=0.2, color='tab:purple')

    plt.title('PEARL')
    plt.ylabel('average return')
    plt.xlabel('iter')
    plt.xlim(0, common_length)
    plt.legend()
    plt.grid()

    plt.tight_layout()
    plt.savefig('vanilla.png')
    """
    plt.clf()
    for i in range(num_results):
        plt.plot(range(length[i]), moving_average(data_total[i], axis=0))
    plt.title('PEARL + GP-MPC')
    plt.ylabel('Average Return')
    plt.xlabel('Iter')
    plt.xlim(0)

    plt.grid()

    plt.savefig('weak_return_individual.png')

    plt.clf()
    for i in range(num_results):
        plt.plot(range(length[i]), moving_average(data_navi[i], axis=0))
    plt.title('PEARL + GP-MPC')
    plt.ylabel('Average Return')
    plt.xlabel('Iter')
    plt.xlim(0)
    plt.grid()

    plt.savefig('weak_navi_individual.png')

    plt.clf()
    for i in range(num_results):
        plt.plot(range(length[i]), moving_average(data_col[i], axis=0))
    plt.title('PEARL + GP-MPC')
    plt.ylabel('Average Return')
    plt.xlabel('Iter')
    plt.xlim(0)
    plt.grid()

    plt.savefig('weak_col_individual.png')
    """

if __name__ == '__main__':
    main(sys.argv)
