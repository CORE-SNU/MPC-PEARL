import numpy as np
import matplotlib.pyplot as plt
import sys


def moving_average(data, window_sz=50, axis=1):
    dim = data.shape[axis]
    processed = np.zeros(shape=data.shape)
    ndim = data.ndim
    for k in range(dim):
        begin = max(0, k - window_sz + 1)
        end = k + 1
        # this produce [:, ..., k, ..., :] where the location of k is specified by axis
        slc = [slice(None)] * ndim
        slc[axis] = k
        # this produce [:, ..., begin: end, ..., :]
        slc_taken = [slice(None)] * ndim
        slc_taken[axis] = slice(begin, end)
        slc = tuple(slc)
        slc_taken = tuple(slc_taken)
        processed[slc] = np.mean(data[slc_taken], axis=axis)
    return processed


def statistics(data, axis=0):
    mean = np.mean(data, axis=axis, keepdims=False)
    std = np.std(data, axis=axis, keepdims=False)
    low, high = mean - 0.5 * std, mean + 0.5 * std
    return mean, low, high


def main(argv):
    num_results = len(argv) - 1
    data = {}
    length = []
    for i in range(num_results):
        file_name = argv[i + 1]
        data[i] = np.genfromtxt(file_name + '/progress.csv', delimiter=',')[1:, 39]
        length.append(data[i].shape[0])

    common_length = min(length)
    aggregated = np.zeros((num_results, common_length))
    for i in range(num_results):
        aggregated[i] = 80. - data[i][:common_length]

    smoothed = moving_average(data=aggregated, axis=1)
    mean, low, high = statistics(smoothed, axis=0)

    x = np.arange(common_length)
    plt.plot(x, mean)
    plt.fill_between(x, low, high, alpha=0.2)
    plt.title('PEARL')
    plt.ylabel('settling time (t)')
    plt.xlabel('iter')
    plt.xlim(0, common_length)
    plt.grid()
    plt.ylim(0)
    plt.tight_layout()
    plt.savefig('reach_vanilla.png')
    """
    plt.clf()
    for i in range(num_results):
        plt.plot(range(length[i]), moving_average(data[i], axis=0))
    plt.title(r'event = goal ($p = 0.1$, $r = 0.6$)')
    plt.ylabel('Average Return')
    plt.xlabel('Iter')
    plt.xlim(0)
    plt.grid()
    plt.ylim(0)
    plt.savefig('reach_individual.png')
    """
if __name__ == '__main__':
    main(sys.argv)
