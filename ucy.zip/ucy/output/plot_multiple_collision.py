import numpy as np
import matplotlib.pyplot as plt
import sys


def moving_average(data, window_sz=50, axis=1):
    dim = data.shape[axis]
    processed = np.zeros(shape=data.shape)
    ndim = data.ndim
    for k in range(dim):
        begin = max(0, k - window_sz + 1)
        end = k + 1
        # this produce [:, ..., k, ..., :] where the location of k is specified by axis
        slc = [slice(None)] * ndim
        slc[axis] = k
        # this produce [:, ..., begin: end, ..., :]
        slc_taken = [slice(None)] * ndim
        slc_taken[axis] = slice(begin, end)
        slc = tuple(slc)
        slc_taken = tuple(slc_taken)
        processed[slc] = np.mean(data[slc_taken], axis=axis)
    return processed


def statistics(data, axis=0):
    mean = np.mean(data, axis=axis, keepdims=False)
    std = np.std(data, axis=axis, keepdims=False)
    low, high = mean - 0.5 * std, mean + 0.5 * std
    return mean, low, high


def main(argv):
    num_results = len(argv) - 1
    data_human = {}
    data_table = {}
    length = []
    for i in range(num_results):
        file_name = argv[i + 1]
        data_human[i] = np.genfromtxt(file_name + '/progress.csv', delimiter=',')[1:, 35]
        data_table[i] = np.genfromtxt(file_name + '/progress.csv', delimiter=',')[1:, 39]
        length.append(data_human[i].shape[0])

    common_length = min(length)
    aggregated_human = np.zeros((num_results, common_length))
    aggregated_table = np.zeros((num_results, common_length))
    for i in range(num_results):
        aggregated_human[i] = data_human[i][:common_length]
        aggregated_table[i] = data_table[i][:common_length]

    smoothed_human = moving_average(data=aggregated_human, axis=1)
    smoothed_table = moving_average(data=aggregated_table, axis=1)

    mean_human, low_human, high_human = statistics(smoothed_human, axis=0)
    mean_table, low_table, high_table = statistics(smoothed_table, axis=0)

    x = np.arange(common_length)
    plt.plot(x, mean_human, linestyle='dotted', color='tab:red', label='human')
    plt.fill_between(x, low_human, high_human, alpha=0.2, color='tab:red')

    plt.plot(x, mean_table, linestyle='dashed', color='tab:purple', label='table')
    plt.fill_between(x, low_table, high_table, alpha=0.2, color='tab:purple')
    plt.legend()
    plt.title('PEARL')
    plt.ylabel('# average collision')
    plt.xlabel('iter')
    plt.xlim(0, common_length)

    plt.grid()

    plt.tight_layout()
    plt.savefig('col_vanilla.png')

    """
    plt.clf()
    for i in range(num_results):
        plt.plot(range(length[i]), moving_average(data_human[i], axis=0))
    plt.title(r'event = goal ($p = 1$, $r = 0.6$)')
    plt.ylabel('Average Return')
    plt.xlabel('Iter')
    plt.xlim(0)
    plt.grid()
    plt.savefig('col_individual.png')
    """

if __name__ == '__main__':
    main(sys.argv)
