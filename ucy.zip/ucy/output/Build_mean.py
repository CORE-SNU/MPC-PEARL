import numpy as np
import matplotlib.pyplot as plt
import sys
import pandas as pd

# Make mean of mulitple files
filename = []
for i, val in enumerate(sys.argv):
	if i >= 1: 
		filename.append(val)

# Load csvs
dataset = []
data_len = []
for data_csv in filename:
	data = pd.read_csv(data_csv)
	data_len.append(len(data))
	dataset.append(data)
data_len = np.min(data_len)

# Make mean of each data
data_mean = {
	'AverageReturn_all_test_tasks':np.zeros([data_len]), 
	'StdReturn_all_test_tasks':np.zeros([data_len]), 
	'AverageReaches_all_test_tasks':np.zeros([data_len]), 
	'StdReaches_all_test_tasks':np.zeros([data_len]), 
	'AverageCollisionTable_all_test_tasks':np.zeros([data_len]), 
	'StdCollisionTable_all_test_tasks':np.zeros([data_len]), 
	'AverageCollisionHuman_all_test_tasks':np.zeros([data_len]), 
	'StdCollisionHuman_all_test_tasks':np.zeros([data_len]),
}

# Clip with minimum data
for data_csv in dataset:
	data_mean['AverageReturn_all_test_tasks'] += data_csv['AverageReturn_all_test_tasks'][:data_len] / len(filename)
	data_mean['StdReturn_all_test_tasks'] += data_csv['StdReturn_all_test_tasks'][:data_len] / len(filename)
	
	data_mean['AverageReaches_all_test_tasks'] += data_csv['AverageReaches_all_test_tasks'][:data_len] / len(filename)
	data_mean['StdReaches_all_test_tasks'] += data_csv['StdReaches_all_test_tasks'][:data_len] / len(filename)
	
	data_mean['AverageCollisionTable_all_test_tasks'] += data_csv['AverageCollisionTable_all_test_tasks'][:data_len] / len(filename)
	data_mean['StdCollisionTable_all_test_tasks'] += data_csv['StdCollisionTable_all_test_tasks'][:data_len] / len(filename)
	
	data_mean['AverageCollisionHuman_all_test_tasks'] += data_csv['AverageCollisionHuman_all_test_tasks'][:data_len] / len(filename)
	data_mean['StdCollisionHuman_all_test_tasks'] += data_csv['StdCollisionHuman_all_test_tasks'][:data_len] / len(filename)

data_mean = pd.DataFrame(data_mean)
data_mean.to_csv('./summary.csv')
