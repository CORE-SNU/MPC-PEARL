import numpy as np
import matplotlib.pyplot as plt
import sys


filename = sys.argv[1]
filename2 = sys.argv[2]
data = np.genfromtxt(filename, delimiter=',')[1:, 0]
data_std = np.genfromtxt(filename, delimiter=',')[1:, 1]
data1 = np.genfromtxt(filename2, delimiter=',')[1:, 0]
data1_std = np.genfromtxt(filename2, delimiter=',')[1:, 1]
length1 = data.shape[0]
length2 = data1.shape[0]
#length2 = 70

window_width = 50
smooth = np.zeros(length1)
smooth1 = np.zeros(length2)
up_b = np.zeros(length2)
low_b = np.zeros(length2)
for i in range(length1):
    begin = max(i - window_width + 1, 0)
    end = i + 1
    smooth[i] = np.mean(data[begin:end])
    
for i in range(length2):
    begin = max(i - window_width + 1, 0)
    end = i + 1   
    smooth1[i] = np.mean(data1[begin:end]) 
    

plt.plot(data, color='tab:red', label=r'PEARL+MPC')
plt.fill_between(np.linspace(0,length1-1,length1), data+data_std, data-data_std, alpha=0.15, color='tab:red')

plt.plot(data1, color='tab:blue', label='PEARL')
plt.fill_between(np.linspace(0,length2-1,length2), data1-data1_std, data1+data1_std, alpha=0.15, color='tab:blue')
plt.legend()
plt.xlabel('Episodes')
plt.ylabel('Return (meta-test)')
plt.xlim(0, max([length1,length2])-1)
#plt.xlim(0, length2-1)
plt.grid()

plt.tight_layout()
plt.savefig('result_test.png')

