import os
import json
import numpy as np
import pandas as pd
import argparse
import matplotlib.pyplot as plt

from test_navigation import main_external_call as run
from configs.default import default_config
from launch_experiment import deep_update_dict

import dataframe_image as dfi


def main(real_time=False, with_mpc=False):
    headers = [
        'reaches_avg',
        'collision_free_ratio',
        'task_completion_ratio',
        'mean_goal_distance',
        'spl'
    ]

    row = {'reaches_avg': 'TT',
           'collision_free_ratio': 'CR',
           'task_completion_ratio': 'TCR',
           'mean_goal_distance': 'MGD',
           'spl': 'SPL'
           }

    # names = ['pearl', 'mpc', 'eps2e-1', 'eps5e-1', 'eps8e-1', 'eps1e0']
    # eps = {'pearl': None, 'mpc': None, 'eps2e-1': 0.2, 'eps5e-1': 0.5, 'eps8e-1': 0.8, 'eps1e0': 1.0}
    names = ['pearl', 'mpc', 'eps2e-1']
    eps = {'pearl': None, 'mpc': None, 'eps2e-1': 0.2}
    save_paths = {name: [] for name in names}
    results = {name: [] for name in names}

    for name in names:
        print('+=================================== {} ===================================+ '.format(name))
        # load the configuration file

        num_trajs = 1 if (name == 'mpc' or real_time) else 3
        mpc_config = (name == 'mpc' or (name != 'pearl' and with_mpc))
        config = './configs/UCY_MPC.json' if mpc_config else './configs/UCY.json'
        variant = default_config
        with open(config) as f:
            exp_params = json.load(f)
            variant = deep_update_dict(exp_params, variant)

        # Up-most directory which contains all training weights corresponding to the mode.
        p = './output/Zara-UCY/adaptation/{}'.format(name)
        # Collection of all down-most subdirectories under the current path.
        # Each subdirectory contains weights needed to run the evaluation function.
        paths = [dirpath for dirpath, dirnames, _ in os.walk(p) if not dirnames]

        mpc_only = True if name == 'mpc' else False

        for i, path in enumerate(paths):
            print('[seed {}]'.format(i), 'path >', path)
            save_path = '{}_res{}.csv'.format(name, i)
            save_paths[name].append(save_path)
            run(config,
                path,
                num_trajs=num_trajs,
                deterministic=True,
                video=False,
                mpc_only=mpc_only,
                save_path=save_path,
                real_time=real_time,
                eps=eps[name]
                )

        for save_path in save_paths[name]:
            res = pd.read_csv(save_path, sep=',', header=0)[headers]
            results[name].append(res)

    data_string = {h: {} for h in headers}

    for h in headers:

        for name in names:
            num_trajs = 1 if (name == 'mpc' or real_time) else 3
            # Processing statistics of lastly adapted trajectory
            if h == 'reaches_avg':
                data = [250 - res['reaches_avg'][num_trajs - 1] for res in results[name]]
            else:
                data = [res[h][num_trajs - 1] for res in results[name]]
            mean = np.mean(data)
            ddof = 0 if name == 'mpc' else 1
            std = np.std(data, ddof=ddof)
            data_string[h][name] = '{:.2f}'.format(mean) + u'\u00B1' + '{:.2f}'.format(std)
            # print('mean = {:.4f}'.format(mean))
            # print('std = {:.4f}'.format(std))

    source = {
        name: [data_string[h][name] for h in headers] for name in names
    }

    table = pd.DataFrame(source, index=pd.Index([row[h] for h in headers]))
    table_name = 'table' + real_time * '_real_time' + with_mpc * '_with_mpc'

    dfi.export(table, table_name + '.png')
    table.to_csv(table_name + '.csv')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--real_time', action='store_true')
    parser.add_argument('--with_mpc', action='store_true')

    args = parser.parse_args()

    main(real_time=args.real_time, with_mpc=args.with_mpc)
