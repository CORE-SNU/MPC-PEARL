import numpy as np
from typing import List
from rlkit.envs.utils.obstacles import Obstacle, CircularObstacle, Human, Box
import os
from itertools import permutations
from tqdm import tqdm


class Zara:
    def __init__(self,
                 num_tasks,
                 num_people,
                 human_radii,
                 ep_len=250,
                 ):

        self.dt = 0.04   # sampling interval
        # number of tasks to generate
        # to reduce the computational burden, we generate multiple scenarios in advance, and sample tasks from these
        self.num_tasks = num_tasks
        self.ep_len = ep_len

        x_min, x_max = -0.02104651, 15.13244069
        y_min, y_max = -0.2386598199999988, 12.3864436
        self.upper_bound = np.array([x_max, y_max])
        self.lower_bound = np.array([x_min, y_min])

        # ------------------------------ Pedestrians Setup ------------------------------
        self.num_people = num_people
        self.human_radii = human_radii

        # self.cycle_radii = cycle_radii      # shape = (number of tasks to be generated, number of people)
        # self.cycle_vel = cycle_vel          # same shape as above

        # self.people_in_task = [[Human(center=None, radii=self.human_radii)] * self.num_people] * self.num_tasks
        # Caution! Don't use multiplication operator as above, since it does not behave as you expect...
        self.people_in_task = [
            [Human(center=None, radii=self.human_radii) for _ in range(self.num_people)]
            for _ in range(self.num_tasks)]
        # offline computation of the trajectories of the moving obstacles
        # this is crucial for computationally light simulation
        # TODO : more complex & interesting obstacle motion
        self.generate_scenarios()

        self.People = []        # placeholder for human objects

        # -------------------------------------------------------------------------------
        # ----------------------------- Box Obstacles Setup -----------------------------
        building = Box(lb=[x_min, 7.0], ub=[9.5, y_max])
        car1 = Box(lb=[9.8, 10.2], ub=[11.7, y_max])
        car2 = Box(lb=[9.9, 5.5], ub=[11.9, 10.3])
        road = Box(lb=[x_min, y_min], ub=[x_max, 1.9])

        self.Boxes = [building, car1, car2, road]
        # -------------------------------------------------------------------------------
        return

    def generate_scenarios(self):
        # toilet -> door
        """
        method for pre-computation of dynamic obstacle trajectories
        strongly recommended for complex motion simulation to generate all tasks in advance
        """
        # print('generating {} scenarios offline...'.format(self.num_tasks))
        trajectories = np.load('./ucy/X.npy')
        for idx in range(self.num_tasks):
            people = self.people_in_task[idx]
            for i in range(self.num_people):
                # set offline trajectory to every human object of a task
                people[i].set_path(trajectories[idx, :, :, i])

    def reset(self):
        # bring back people to their spawn point
        for human in self.People:
            human.init()
        # self.human_center_list = [[-0.9, 0.], [0., 0.9]]

    def reset_task(self, idx):
        self.People = self.people_in_task[idx]

    def sim(self):
        # simulate motions of the dynamic obstacles
        for human in self.People:
            human.sim()
        #     self.human_center_list[i] = human.center      # update position of each guest
        return

    @property
    def obstacle_list(self):
        # list of every existing obstacles
        return (self.Boxes+self.People)[:]

    @property
    def box_list(self) -> List[Box]:
        # list of every existing obstacles
        return self.Boxes[:]

    @property
    def human_list(self) -> List[CircularObstacle]:
        # list of every existing obstacles
        return self.People[:]
    
    @property
    def human_vector(self) -> np.ndarray:
        # return the real-time positions of all people as a flat numpy array
        human_center_list = [human.center for human in self.People]
        return np.reshape(np.array(human_center_list), self.num_people * 2)


