import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import DotProduct, WhiteKernel, ConstantKernel, RBF
import casadi as ca
import warnings

def rollout(
		env,
		agent,
		max_path_length=np.inf,
		accum_context=True,
		train=True,
		animated=False,
		save_frames=False,
		use_MPC=False,
		mpc_solver=None,
		gp_human=None,
		test=False,
		pred=None,
):
	"""
	The following value for the following keys will be a 2D array, with the
	first dimension corresponding to the time dimension.
	 - observations
	 - actions
	 - rewards
	 - next_observations
	 - terminals

	The next two elements will be lists of dictionaries, with the index into
	the list being the index into the time
	 - agent_infos
	 - env_infos

	:param env:
	:param agent:
	:param max_path_length:
	:param accum_context: if True, accumulate the collected context
	:param animated:
	:param save_frames: if True, save video of rollout
	:return:
	"""

	observations = []
	next_observations = []
	actions = []
	rewards = []
	terminals = []
	agent_infos = []
	env_infos = []
	o = env.reset()
	next_o = None
	path_length = 0
	pred_horizon = env.Nt


	# Custom information
	collisions_human = []
	collisions_table = []
	reaches = []
	navi_parts = []
	col_parts = []

	if animated:
		env.render(pred=pred)

	# Data for obstacle GP
	prediction = []
	max_data_size = env.Nt // 2
	min_data_size = env.Nt // 4
	solver_opts = {}
	solver_opts['expand'] = False
	human = []
	human_next = []
	dynamic = []
	use_GP, no_GP = 0, 0

	# To use only human data for GP
	# obs = env.restaurant.table_list

	while path_length < max_path_length:
		cond1 = env.goal_event
		#cond2 = (path_length % env.interval == env.interval - 1) and not env.collision_event
		cond2 = (path_length % env.interval == env.interval - 1)
		cond3 = use_MPC and test
		turn_on_mpc = cond1 or cond2 or cond3

		# build prediction matrix
		pred_cov = 1e-5*np.ones((env.Nt, env.num_people, 2))
		pred = np.zeros((env.Nt, env.num_people, 2))
		for t in range(pred.shape[0]):
			pred[t, :, :] = o[3:3+2*env.num_people].reshape(-1, pred.shape[2])
		
		# use GP-MPC if it is turned on
		if env.landed:
			# If the robot lands on the goal, then do not give a control anymore.
			a = np.zeros(env.action_space.shape[0])
			agent_info = {}
			Xout = None
		else:
			if turn_on_mpc:
				# Use GP to build constraints
				if len(observations) > min_data_size:
					pred, pred_cov = fit_GP_adaptive(observations, next_observations, pred, pred_cov, max_data_size=max_data_size, min_data_size=min_data_size, num_people=env.num_people, pred_horizon=env.Nt)
				# if (rand_var <= env.eps and env.event) or (col and use_MPC and test):
				# Caution! You must pass only the list of static obstacles as an argument to GP-MPC solver
				# TODO2: Pass GP-generated K-step obstacle prediction to MPC as constraint
				Xout, a_MPC, flag = mpc_solver.plan_pol(
					o[:3],
					env._goal,  # Goal position given to MPC
					env.restaurant.table_radii,
					env.restaurant.human_radii,
					env.restaurant.table_list,
					pred,
					pred_cov,
					env._counter
				)
				agent_info = {}
				if flag == 1:
					a = a_MPC
				else:
					a = a_MPC * 0.
					Xout = None
			else:
				Xout = None
				a, agent_info = agent.get_action(o)

		prediction.append(pred)

		# episode roll-out
		next_o, r, d, a, _, info_custom, env_info = env.step(a, train, Xout=Xout, use_MPC=use_MPC)

		# append custom info
		collision_human, collision_table, reach, navi_part, col_part = info_custom
		collisions_human.append(collision_human)
		collisions_table.append(collision_table)
		reaches.append(reach)
		navi_parts.append(navi_part)
		col_parts.append(col_part)

		# update the agent's current context
		human_next.append(next_o[3:3+2*env.num_people].reshape(-1, 2))
		if accum_context:
			agent.update_context([o, a, r, next_o, d, env_info])
		observations.append(o)
		next_observations.append(next_o)
		rewards.append(r)
		terminals.append(d)
		actions.append(a)
		agent_infos.append(agent_info)
		path_length += 1
		o = next_o

		if animated:
			if use_MPC:
				env.render(pred=prediction)
			else:
				env.render(pred=None)

		env_infos.append(env_info)
		if d:
			break

	""" Summarize results """
	actions = np.array(actions)
	if len(actions.shape) == 1:
		actions = np.expand_dims(actions, 1)
	observations = np.array(observations)
	if len(observations.shape) == 1:
		observations = np.expand_dims(observations, 1)
		next_o = np.array([next_o])
	next_observations = np.vstack(
		(
			observations[1:, :],
			np.expand_dims(next_o, 0)
		)
	)
	return dict(
		observations=observations,
		actions=actions,
		rewards=np.array(rewards).reshape(-1, 1),
		next_observations=next_observations,
		terminals=np.array(terminals).reshape(-1, 1),
		agent_infos=agent_infos,
		env_infos=env_infos,
		collisions_human=collisions_human,
		collisions_table=collisions_table,
		reaches=reaches,
		navi_parts=np.array(navi_parts).reshape(-1, 1),
		col_parts=np.array(col_parts).reshape(-1, 1),
		gp_human=(use_GP, no_GP),
		pred=pred
	)


def split_paths(paths):
	"""
	Stack multiples obs/actions/etc. from different paths
	:param paths: List of paths, where one path is something returned from
	the rollout functino above.
	:return: Tuple. Every element will have shape batch_size X DIM, including
	the rewards and terminal flags.
	"""
	rewards = [path["rewards"].reshape(-1, 1) for path in paths]
	terminals = [path["terminals"].reshape(-1, 1) for path in paths]
	actions = [path["actions"] for path in paths]
	obs = [path["observations"] for path in paths]
	next_obs = [path["next_observations"] for path in paths]
	rewards = np.vstack(rewards)
	terminals = np.vstack(terminals)
	obs = np.vstack(obs)
	actions = np.vstack(actions)
	next_obs = np.vstack(next_obs)
	assert len(rewards.shape) == 2
	assert len(terminals.shape) == 2
	assert len(obs.shape) == 2
	assert len(actions.shape) == 2
	assert len(next_obs.shape) == 2
	return rewards, terminals, obs, actions, next_obs


def split_paths_to_dict(paths):
	rewards, terminals, obs, actions, next_obs = split_paths(paths)
	return dict(
		rewards=rewards,
		terminals=terminals,
		observations=obs,
		actions=actions,
		next_observations=next_obs,
	)
'''
def get_stat_in_paths(paths, dict_name, scalar_name):
	if len(paths) == 0:
		return np.array([[]])

	if type(paths[0][dict_name]) == dict:
		# Support rllab interface
		return [path[dict_name][scalar_name] for path in paths]

	return [
		[info[scalar_name] for info in path[dict_name]]
		for path in paths
	]
'''
def fit_GP_adaptive(obs, next_obs, pred, pred_cov, max_data_size=10, min_data_size=2, num_people=5, pred_horizon=10):
	# Adaptively use closest obstacle to fit GP

	# Maximum data length
	obs, next_obs = obs[-max_data_size:], next_obs[-max_data_size:]

	# Current robot position
	robot_pos = next_obs[-1][:2]
	
	# Clip obstacle states & adaptively select dataset to use
	v, dist = {i:[] for i in range(num_people)}, {i:[] for i in range(num_people)}
	human, next_human = [], []
	
	for human_pos, next_human_pos in zip(obs, next_obs):
		human_pos = np.array(human_pos[3:3+2*num_people]).reshape(-1,2)
		next_human_pos = np.array(next_human_pos[3:3+2*num_people]).reshape(-1,2)
		human.append(human_pos)
		next_human.append(next_human_pos)
		for i in range(num_people):
			v[i].append( np.linalg.norm( next_human_pos[i, :] - human_pos[i, :] ) )
			dist[i].append( np.linalg.norm( next_human_pos[i, :] - robot_pos ) )

	# Adapatively select obstacle to use
	adaptive_set = []
	min_v = 1e-3	# Don't use fixed obstacle, since it will harm GP performance!
	range_adapt = 1
	for i in range(num_people):
		if np.max(v[i]) > min_v:
			if np.min(dist[i]) < range_adapt:	# See if obstacle is in range
				adaptive_set.append(i)
	# adaptive_set = range(num_people)
	
	#print('obstacle in use :',len(adaptive_set))
	if len(adaptive_set) < 1:
		return pred, pred_cov
	'''
	# Build dataset and fit GP
	X = [pos[adaptive_set, :].reshape(1,-1)[0] for pos in human]
	y = [pos[adaptive_set, :].reshape(1,-1)[0] for pos in next_human]

	data_len = max_data_size
	while data_len >= min_data_size:
		with warnings.catch_warnings(record=True) as w:
			warnings.simplefilter("always")
			kernel = ConstantKernel() + RBF() * ConstantKernel()
			gp_human = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=5)
			gp_human.fit(X[-data_len:], y[-data_len:])
			if len(w) == 0:
				print('trained with data length :',data_len)
				break
		data_len -= 1
	# Return prediction!
	cur_state = y[-1]
	for t in range(pred_horizon):
		pred[t, adaptive_set, :] = np.array(cur_state.copy()).reshape(-1,2)
		cur_state = gp_human.predict([cur_state])[0]
	'''
	for i in adaptive_set:
		X = [pos[i, :].reshape(1,-1)[0] for pos in human]
		y = [pos[i, :].reshape(1,-1)[0] for pos in next_human]
		y0 = [pos[i, 0].reshape(1,-1)[0] for pos in next_human]
		y1 = [pos[i, 1].reshape(1,-1)[0] for pos in next_human]
		y_diff0 = [y[i][0] - X[i][0] for i in range(len(X))]
		y_diff1 = [y[i][1] - X[i][1] for i in range(len(X))]
		"""
		kernel = ConstantKernel() * RBF()
		gp_human = GaussianProcessRegressor()
		gp_human.fit(X, y)
		
		cur_state = y[-1]
		for t in range(pred_horizon):
			# Return prediction!
			pred[t, i, :] = np.array(cur_state.copy()).reshape(-1,2)
			cur_state = gp_human.predict([cur_state])[0]
		"""
		kernel = ConstantKernel() + RBF() * ConstantKernel()
		#data_len = max_data_size
		#while data_len >= min_data_size:
		with warnings.catch_warnings(record=True) as w:
			warnings.simplefilter("always")
			gp_human0 = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=20)
			#gp_human0.fit(X[-max_data_size:], y0[-max_data_size:])
			gp_human0.fit(X[-max_data_size:], y_diff0[-max_data_size:])
			# gp_human1 = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=10)
			# gp_human1.fit(X[-data_len:], y1[-data_len:])
			#if len(w) == 0:
			#	print('trained with data length :', data_len)
			#	break

		kernel = ConstantKernel() + RBF() * ConstantKernel()
		#data_len = max_data_size
		#while data_len >= min_data_size:
		with warnings.catch_warnings(record=True) as w:
			warnings.simplefilter("always")
			# gp_human0 = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=10)
			# gp_human0.fit(X[-data_len:], y0[-data_len:])
			gp_human1 = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=20)
			#gp_human1.fit(X[-max_data_size:], y1[-max_data_size:])
			gp_human1.fit(X[-max_data_size:], y_diff1[-max_data_size:])
			#if len(w) == 0:
			#	print('trained with data length :', data_len)
			#	break
		#	data_len -= 1

		cur_state = y[-1]
		cur_cov = [0, 0]
		for t in range(pred_horizon):
			# Return prediction!
			# print(cur_state)
			pred[t, i, :] = np.array(cur_state.copy()).reshape(-1,2)
			pred_cov[t, i, :] = np.array(cur_cov)
			vel_0, cur_cov0 = gp_human0.predict([cur_state], return_cov = True)
			vel_1, cur_cov1 = gp_human1.predict([cur_state], return_cov = True)
			cur_state0 = cur_state[0] + vel_0[0]
			cur_state1 = cur_state[1] + vel_1[0]
			cur_state = [cur_state0, cur_state1]
			cur_cov = [cur_cov0[0][0], cur_cov1[0][0]]
	#print('')
	return pred, pred_cov
