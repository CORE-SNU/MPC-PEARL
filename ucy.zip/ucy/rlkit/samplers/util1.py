import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import DotProduct, WhiteKernel, ConstantKernel, RBF
import casadi as ca
import warnings

def rollout(
		env,
		agent,
		max_path_length=np.inf,
		accum_context=True,
		train=True,
		animated=False,
		save_frames=False,
		use_MPC=False,
		mpc_solver=None,
		gp_human=None,
		test=False,
		pred=None,
) -> dict:
	"""
	The following value for the following keys will be a 2D array, with the
	first dimension corresponding to the time dimension.
	 - observations
	 - actions
	 - rewards
	 - next_observations
	 - terminals

	The next two elements will be lists of dictionaries, with the index into
	the list being the index into the time
	 - agent_infos
	 - env_infos

	:param env:
	:param agent:
	:param max_path_length:
	:param accum_context: if True, accumulate the collected context
	:param animated:
	:param save_frames: if True, save video of rollout
	:return:
	"""

	observations = []
	next_observations = []
	actions = []
	rewards = []
	terminals = []
	agent_infos = []
	env_infos = []
	o = env.reset()
	next_o = None
	path_length = 0
	pred_horizon = env.Nt

	# Custom information
	collisions_human = []
	collisions_table = []
	reaches = []
	navi_parts = []
	col_parts = []

	if animated:
		env.render(pred=pred)

	# Data for obstacle GP
	prediction = []
	max_data_size = env.Nt // 2
	min_data_size = env.Nt // 4
	solver_opts = {}
	solver_opts['expand'] = False
	human = []
	human_next = []
	dynamic = []
	use_GP, no_GP = 0, 0		# count the number of failures of GP

	# To use only human data for GP
	# obs = env.restaurant.table_list

	while path_length < max_path_length:
		# GP-MPC activation condition specification
		cond1 = env.goal_event
		cond2 = (path_length % env.interval == env.interval - 1) and not env.collision_event
		cond3 = use_MPC and test
		turn_on_mpc = cond1 or cond2 or cond3

		pred = np.zeros((env.Nt, env.num_people, 2))
		human.append(o[3:3 + 2 * env.num_people].copy().reshape(-1, 2))
		mean_t = o[3:3 + 2 * env.num_people].copy().reshape(1, -1)  # To use in GP rollout

		# use GP-MPC if it is turned on
		if env.landed:
			# If the robot lands on the goal, then do not give a control anymore.
			a = np.zeros(env.action_space.shape[0])
			agent_info = {}
			for t in range(pred_horizon):
				pos_t = np.reshape(mean_t, (-1, 2))
				num_obs, dim = pos_t.shape
				for i in range(num_obs):
					pred[t, i, :] = pos_t[i, :].copy()
			Xout = None
		else:
			if use_MPC and train:
				obs_dynamic = []

				# Use closest table and human to build MPC
				# Use mean value from GP to estimate position

				if gp_human[0] is not None:
					pos_t = np.reshape(mean_t.copy(), (-1, 2))
					pos_dynamic = np.reshape(pos_t[dynamic, :], (1, -1)) # positions to predict
					num_obs, dim = pos_t.shape # parameters

					# Rollout for t steps
					for t in range(pred_horizon):
						pos_dynamic = np.reshape(pos_dynamic, (-1, 2))

						# Append estimated position
						for i in range(num_obs):
							if i in dynamic:
								X = pos_dynamic[dynamic.index(i), :].copy()
								obs_dynamic.append(X)
								pred[t,i,:] = X
								if len(gp_human) > 1: # 1 GP for 1 obstacle here!
									gp = gp_human[i]
									pos_dynamic[dynamic.index(i), :] = gp.predict(X.reshape(1, -1))
							else:
								obs_dynamic.append(pos_t[i, :])
								pred[t,i,:] = pos_t[i,:].copy()

						if len(gp_human) == 1: # 1 GP for whole obstacle here!
							gp = gp_human[0]
							pos_dynamic = gp.predict(pos_dynamic.reshape(1, -1))

				else:
					# If GP unavailable, give current positions of obstacles
					for t in range(pred_horizon):
						pos_t = np.reshape(mean_t, (-1, 2))
						num_obs, dim = pos_t.shape
						for i in range(num_obs):
							obs_dynamic.append(pos_t[i, :])
							pred[t, i, :] = pos_t[i, :].copy()

				# Trash prediction if it results in sparse trajectory
				v_thres = 0.05
				for i in range(env.num_people):
					pred_i_x = pred[:, i, 0]
					pred_i_y = pred[:, i, 1]
					v_x, v_y = np.diff(pred_i_x), np.diff(pred_i_y)
					v = np.sqrt(v_x ** 2 + v_y ** 2)
					if np.mean(v) > v_thres:
						# Too fast! incorrect estimation
						pred[:,i,0] = np.ones(len(pred[:,i,0])) * pred[0,i,0]
						pred[:,i,1] = np.ones(len(pred[:,i,1])) * pred[0,i,1]

				# Use closest human
				d_min, new_pred = np.inf, np.zeros((env.Nt, 1, 2))
				for i in range(env.num_people):
					pred_i_x = pred[:,i,0]
					pred_i_y = pred[:,i,1]
					d_x, d_y = pred_i_x - np.ones(len(pred_i_x)) * o[0], pred_i_x - np.ones(len(pred_i_y)) * o[1]
					d = np.sqrt(d_x ** 2 + d_y ** 2)
					if np.mean(d) < d_min:
						new_pred = pred[:,i,:]

				# Use closest table
				dist_table = [np.linalg.norm(table.center - o[0:2]) for table in env.restaurant.table_list]
				min_table = np.argmin(dist_table)
				# new_table_list = [env.restaurant.table_list[min_table]]

				prediction.append(pred)

				if turn_on_mpc:
					# Caution! You must pass only the list of static obstacles as an argument to GP-MPC solver
					# TODO2: Pass GP-generated K-step obstacle prediction to MPC as constraint
					Xout, a_MPC, flag = mpc_solver.plan_pol(
						o[:3],
						env._goal,  # Goal position given to MPC
						env.restaurant.table_radii,
						env.restaurant.human_radii,
						env.restaurant.table_list,
						pred,
						env._counter
					)
					# check whether GP is infeasible
					if gp_human[0] is None and len(dynamic) > 0:
						no_GP += 1
					else:
						use_GP += 1

					agent_info = {}
					if flag:
						a = a_MPC
					else:
						a = a_MPC * 0.
				else:
					Xout = None
					a, agent_info = agent.get_action(o)
			else:
				Xout = None
				a, agent_info = agent.get_action(o)

		# episode roll-out
		next_o, r, d, a, _, info_custom, env_info = env.step(a, train, Xout=Xout, use_MPC=use_MPC)

		# append custom info
		collision_human, collision_table, reach, navi_part, col_part = info_custom
		collisions_human.append(collision_human)
		collisions_table.append(collision_table)
		reaches.append(reach)
		navi_parts.append(navi_part)
		col_parts.append(col_part)

		# update the agent's current context
		human_next.append(next_o[3:3+2*env.num_people].reshape(-1, 2))
		if accum_context:
			agent.update_context([o, a, r, next_o, d, env_info])
		observations.append(o)
		next_observations.append(next_o)
		rewards.append(r)
		terminals.append(d)
		actions.append(a)
		agent_infos.append(agent_info)
		path_length += 1
		o = next_o
		
		if animated:
			if use_MPC:
				env.render(pred=prediction)
			else:
				env.render(pred=None)
		if save_frames:
			from PIL import Image
			image = Image.fromarray(np.flipud(env.get_image()))
			env_info['frame'] = image
		env_infos.append(env_info)
		if d:
			break

		# If we use MPC at next step!
		if use_MPC and turn_on_mpc:
			# Data for GP
			X = human.copy()
			Y = human_next.copy()
			kernel = ConstantKernel() * RBF()

			# Preprocess data - length
			if len(X) > max_data_size:
				X = X[-max_data_size:] 
				Y = Y[-max_data_size:]

			num_people, _ = X[-1].shape
			dynamic_old = dynamic
			dynamic = []

			# Preprocess data - dynamic obstacle
			for i in range(num_people):
				prev = [x[i, :] for x in X]
				curr = [y[i, :] for y in Y]
				if np.mean(np.abs(np.array(prev) - np.array(curr))) > 5e-3:
					#dynamic.append(i)
					if np.linalg.norm(np.array(next_o[:2]) - np.array(curr)) < 0.5:
						dynamic.append(i)

			print('* # of dynamic object :',len(dynamic))
		else:
			dynamic = []

		if len(dynamic) == 0:
			gp_human = [None]
		
		# Test & update GP
		elif gp_human[0] is not None and use_MPC and turn_on_mpc:
			# Single GP version - remove for speed!
			# X_old = [x[dynamic_old, :].reshape(1,-1)[0] for x in X]
			# Y_old = [y[dynamic_old, :].reshape(1,-1)[0] for y in Y]
		
			X = [x[dynamic, :].reshape(1, -1)[0] for x in X]
			Y = [y[dynamic, :].reshape(1, -1)[0] for y in Y]

			'''
			gp_human = gp_human[0]
			Y_pred = gp_human.predict(X_old[-1].reshape(1, -1))
			Y_true = Y_old[-1].reshape(1, -1)
			# print('* Estimation MSE : %.4f'%(np.sum(((Y_pred - Y_true) ** 2))))
			'''
			gp_human_old = gp_human[0]

			with warnings.catch_warnings(record=True) as w:
				warnings.simplefilter("always")
				gp_human = GaussianProcessRegressor(kernel=kernel)
				gp_human.fit(X, Y)
				print('* Fitting GP with score : %.4f'%(gp_human.score(X, Y)))
				if len(w) == 1:
					gp_human = gp_human_old
					dynamic = dynamic_old
				
				# Wrap GPs with list
				gp_human = [gp_human]
			'''
			# 1 GP for each obstacle
			pos_t = np.reshape(o[2:], (-1, 2))
			next_pos_t = np.reshape(next_o[2:], (-1, 2))
			num_people, _ = pos_t.shape
			MSE = 0
			
			# Estimation error with current GP
			for i in dynamic_old:
				gp = gp_human[i]
				Y_pred = gp.predict(pos_t[i, :].reshape(1,-1))
				Y_true = next_pos_t[i, :].reshape(1,-1)
				MSE += np.sum((Y_pred - Y_true) ** 2)
			print('* Estimation MSE : %.4f'%(MSE/num_people))
			
			gp_human_old = gp_human
			gp_human, score = {i:0 for i in range(num_people)}, 0
			dynamic_new, gp_count = [], 0
			for i in dynamic:
				X_train = [x[i,:].reshape(1,-1)[0] for x in X]
				Y_train = [y[i,:].reshape(1,-1)[0] for y in Y]
				with warnings.catch_warnings(record=True) as w:
					warnings.simplefilter("always")
					gp = GaussianProcessRegressor(kernel=kernel)
					gp.fit(X_train, Y_train)
					if len(w) == 0:
						gp_human[i] = gp
						score += gp.score(X_train, Y_train)
						gp_count += 1
						dynamic_new.append(i)
					else:
						gp_human[i] = gp_human_old[i]
						if i in dynamic_old:
							dynamic_new.append(i)
			dynamic = dynamic_new
			print('# of GP :',len(dynamic))
			print('* Fitting GP with score : %.4f'%(score/num_people))
			'''

		# Initialze GP
		elif gp_human[0] is None and len(X) > min_data_size and use_MPC and turn_on_mpc:
			# 1 GP for whole obstacle
			if len(dynamic) > 0:
				X = [x[dynamic, :].reshape(1,-1)[0] for x in X]
				Y = [y[dynamic, :].reshape(1,-1)[0] for y in Y]
				
				gp_human_old = gp_human[0]

				with warnings.catch_warnings(record=True) as w:
					warnings.simplefilter("always")
					gp_human = GaussianProcessRegressor(kernel=kernel)
					gp_human.fit(X, Y)
					print('* Fitting GP with score : %.4f'%(gp_human.score(X, Y)))
					if len(w) == 1:
						gp_human = gp_human_old
						dynamic = dynamic_old
				
				# Wrap GP with list
				gp_human = [gp_human]
			'''
			# 1 GP for each obstacle
			gp_human_old = gp_human
			gp_human, score = {i:0 for i in range(num_people)}, 0
			dynamic_new, gp_count = [], 0
			for i in dynamic:
				X_train = [x[i,:].reshape(1,-1)[0] for x in X]
				Y_train = [y[i,:].reshape(1,-1)[0] for y in Y]
				with warnings.catch_warnings(record=True) as w:
					warnings.simplefilter("always")
					gp = GaussianProcessRegressor(kernel=kernel)
					gp.fit(X_train, Y_train)
					if len(w) == 0:
						gp_human[i] = gp
						score += gp.score(X_train, Y_train)
						gp_count += 1
						dynamic_new.append(i)
					else:
						gp_human[i] = gp_human_old[i]
						if i in dynamic_old:
							dynamic_new.append(i)
			dynamic = dynamic_new
			print('# of GP :',len(dynamic))
			print('* Fitting GP with score : %.4f'%(score/num_people))
			'''

	""" Summarize results """
	actions = np.array(actions)
	if len(actions.shape) == 1:
		actions = np.expand_dims(actions, 1)
	observations = np.array(observations)
	if len(observations.shape) == 1:
		observations = np.expand_dims(observations, 1)
		next_o = np.array([next_o])
	next_observations = np.vstack(
		(
			observations[1:, :],
			np.expand_dims(next_o, 0)
		)
	)
	return dict(
		observations=observations,
		actions=actions,
		rewards=np.array(rewards).reshape(-1, 1),
		next_observations=next_observations,
		terminals=np.array(terminals).reshape(-1, 1),
		agent_infos=agent_infos,
		env_infos=env_infos,
		collisions_human=collisions_human,
		collisions_table=collisions_table,
		reaches=reaches,
		navi_parts=np.array(navi_parts).reshape(-1, 1),
		col_parts=np.array(col_parts).reshape(-1, 1),
		gp_human=(use_GP, no_GP),
		pred=pred
	)


def split_paths(paths):
	"""
	Stack multiples obs/actions/etc. from different paths
	:param paths: List of paths, where one path is something returned from
	the rollout functino above.
	:return: Tuple. Every element will have shape batch_size X DIM, including
	the rewards and terminal flags.
	"""
	rewards = [path["rewards"].reshape(-1, 1) for path in paths]
	terminals = [path["terminals"].reshape(-1, 1) for path in paths]
	actions = [path["actions"] for path in paths]
	obs = [path["observations"] for path in paths]
	next_obs = [path["next_observations"] for path in paths]
	rewards = np.vstack(rewards)
	terminals = np.vstack(terminals)
	obs = np.vstack(obs)
	actions = np.vstack(actions)
	next_obs = np.vstack(next_obs)
	assert len(rewards.shape) == 2
	assert len(terminals.shape) == 2
	assert len(obs.shape) == 2
	assert len(actions.shape) == 2
	assert len(next_obs.shape) == 2
	return rewards, terminals, obs, actions, next_obs


def split_paths_to_dict(paths):
	rewards, terminals, obs, actions, next_obs = split_paths(paths)
	return dict(
		rewards=rewards,
		terminals=terminals,
		observations=obs,
		actions=actions,
		next_observations=next_obs,
	)


def get_stat_in_paths(paths, dict_name, scalar_name):
	if len(paths) == 0:
		return np.array([[]])

	if type(paths[0][dict_name]) == dict:
		# Support rllab interface
		return [path[dict_name][scalar_name] for path in paths]

	return [
		[info[scalar_name] for info in path[dict_name]]
		for path in paths
	]
