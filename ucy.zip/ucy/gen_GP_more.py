import os
import shutil
import os.path as osp
import pickle5 as pickle
import json
import numpy as np
import click
import torch
import csv
import random
import time

from rlkit.envs import ENVS
from rlkit.envs.wrappers import NormalizedBoxEnv
from rlkit.torch.sac.policies import TanhGaussianPolicy
from rlkit.torch.networks import FlattenMlp, MlpEncoder, RecurrentEncoder
from rlkit.torch.sac.agent import PEARLAgent
from configs.default import default_config
from launch_experiment import deep_update_dict
from rlkit.torch.sac.policies import MakeDeterministic
from rlkit.samplers.util_gp import rollout
from rlkit.torch.sac.sac import PEARLSoftActorCritic

from multiprocessing import Pool

# from gp_mpc import InitGP, GP

class fake_agent():
    def __init__(self):
        with open('gp_human_more.pickle', 'rb') as handle:
            self.gp_predictions = pickle.load(handle)

def wraped_rollout(arg):
    variant, idx = arg

    variant['env_params']['n_tasks'] = 405
    env = NormalizedBoxEnv(ENVS[variant['env_name']](**variant['env_params']))
    env.reset_more_task(idx)
    agent = fake_agent()
    path = rollout( env, 
                    agent, 
                    max_path_length=variant['algo_params']['max_path_length'],
                    accum_context=True,
                    animated=False,
                    use_MPC=True,
                    test=True,
                    mpc_solver=None,
                    pred=None
                    )
    return path


def sim_policy(variant, path_to_exp, num_trajs=1, deterministic=False, save_video=False):
    '''
    simulate a trained policy adapting to a new task
    optionally save videos of the trajectories - requires ffmpeg

    :variant: experiment configuration dict
    :path_to_exp: path to exp folder
    :num_trajs: number of trajectories to simulate per task (default 1)
    :deterministic: if the policy is deterministic (default stochastic)
    :save_video: whether to generate and save a video (default False)
    '''

    # create multi-task environment and sample tasks
    variant['env_params']['n_tasks'] = 405
    env = NormalizedBoxEnv(ENVS[variant['env_name']](**variant['env_params']))
    # tasks = env.get_all_task_idx()
    tasks = range(205, 405)
    #tasks = env.get_gp_task_idx()
    obs_dim = int(np.prod(env.observation_space.shape))
    action_dim = int(np.prod(env.action_space.shape))
    eval_tasks=list(tasks[-variant['n_eval_tasks']:])
    #print('testing on {} test tasks, {} trajectories each'.format(len(eval_tasks), num_trajs))

    # instantiate networks
    latent_dim = variant['latent_size']
    context_encoder = latent_dim * 2 if variant['algo_params']['use_information_bottleneck'] else latent_dim
    reward_dim = 1
    net_size = variant['net_size']
    recurrent = variant['algo_params']['recurrent']
    encoder_model = RecurrentEncoder if recurrent else MlpEncoder

    '''
    qf1 = FlattenMlp(
        hidden_sizes=[net_size, net_size, net_size],
        input_size=obs_dim + action_dim + latent_dim,
        output_size=1,
    )
    qf2 = FlattenMlp(
        hidden_sizes=[net_size, net_size, net_size],
        input_size=obs_dim + action_dim + latent_dim,
        output_size=1,
    )
    vf = FlattenMlp(
        hidden_sizes=[net_size, net_size, net_size],
        input_size=obs_dim + latent_dim,
        output_size=1,
    )
    context_encoder = encoder_model(
        hidden_sizes=[200, 200, 200],
        input_size=2*obs_dim + action_dim + reward_dim,
        output_size=context_encoder,
    )
    policy = TanhGaussianPolicy(
        hidden_sizes=[net_size, net_size, net_size],
        obs_dim=obs_dim + latent_dim,
        latent_dim=latent_dim,
        action_dim=action_dim,
    )
    agent = PEARLAgent(
        latent_dim,
        context_encoder,
        policy,
        **variant['algo_params']
    )
    algorithm = PEARLSoftActorCritic(
        env=env,
        train_tasks=list(tasks[:variant['n_train_tasks']]),
        eval_tasks=list(tasks[-variant['n_eval_tasks']:]),
        nets=[agent, qf1, qf2, vf],
        latent_dim=latent_dim,
        **variant['algo_params']
    )    
    # deterministic eval
    if deterministic:
        agent = MakeDeterministic(agent)

    # load trained weights (otherwise simulate random policy)
    context_encoder.load_state_dict(torch.load(os.path.join(path_to_exp, 'context_encoder.pth')))
    policy.load_state_dict(torch.load(os.path.join(path_to_exp, 'policy.pth')))
    algorithm.pretrain()
    '''
    gp_predictions = {i: {'mean':[], 'cov':[]} for i in tasks}
    agent = fake_agent()
    #'''
    # Generate GP
    start = time.time()
    args = [(variant, idx) for idx in tasks]

    # multiprocessing
    with Pool(25) as p:
        res = p.map(wraped_rollout, args)

    for idx, path in enumerate(res):
        gp_predictions[idx+205]['mean'], gp_predictions[idx+205]['cov'] = path['prediction_mean'], path['prediction_cov']

    print('## testing time / task : ', (time.time() - start)/len(args))
    '''
    # no mulitprocessing
    time_idx = 0
    start = time.time()
    for idx in tasks[40:50]:
        time_idx += 1
        print('## task id :',idx)
        env.reset_task(idx)
        
        paths = []
        
        if not variant['algo_params']['use_MPC']:
            env.eps = 0.

        path = rollout(env,
                       agent,
                       max_path_length=variant['algo_params']['max_path_length'],
                       accum_context=True,
                       animated=False,
                       use_MPC=variant['algo_params']['use_MPC'],
                       test=True,
                       mpc_solver=None,
                       save_frames=False,
                       pred=None
                       )
        paths.append(path)

        gp_predictions[idx]['mean'], gp_predictions[idx]['cov'] = path['prediction_mean'], path['prediction_cov']
            
        # To check number of trajs that use GP / not use GP
        use_GP, no_GP = path['gp_human']

        gp_human = [None]

        print('## testing time / task : ',(time.time() - start)/(time_idx))
        print('## GP time / task      : ',path['gp_time'])
        print('')
    '''
    with open('gp_human_fast_more.pickle', 'wb') as handle:
        pickle.dump(gp_predictions, handle, protocol=pickle.HIGHEST_PROTOCOL)


@click.command()
@click.argument('config', default=None)
@click.argument('path', default=None)
@click.option('--num_trajs', default=10)
@click.option('--deterministic', is_flag=True, default=False)
@click.option('--video', is_flag=True, default=False)
def main(config, path, num_trajs, deterministic, video):
    np.random.seed(666)
    variant = default_config
    if config:
        with open(osp.join(config)) as f:
            exp_params = json.load(f)
        variant = deep_update_dict(exp_params, variant)
    sim_policy(variant, path, num_trajs, deterministic, video)


if __name__ == "__main__":
    main()
