import matplotlib.pyplot as plt
import pickle
import time
import numpy as np
import os
from scipy.interpolate import BSpline


def export_legend(legend, filename='legend.pdf'):
    fig = legend.figure
    fig.canvas.draw()
    bbox = legend.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
    fig.savefig(filename, dpi='figure', bbox_inches=bbox)
    return

dirname = './trajectories'
os.makedirs(dirname, exist_ok=True)

adapted = True
num_tables = 5
num_people = 6
table_radii = 0.5
human_radii = 0.25
ep_len = 80
alpha_min = 0.05
alpha_max = 0.5
lr = 0.25

init_pos = (-4.5, 4.5)
goal_pos = (3.5, -3.5)

f_tables = open('tables.pkl', 'rb')
tables = pickle.load(f_tables)

for idx in range(180, 205):
    colors = iter(['tab:brown'])
    labels = iter(['PEARL'])
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.set_aspect('equal')


    table_pos = tables['task{}'.format(idx-180)]
    for i in range(num_tables):
        x_table = table_pos[2 * i]
        y_table = table_pos[2 * i + 1]
        obstacle = plt.Circle((x_table, y_table),
                              table_radii,
                              color='tab:blue'
                              )
        ax.add_artist(obstacle)
    ax.grid(True)
    ax.set_xlim(-5., 5.)
    ax.set_ylim(-5., 5.)

    for name in ['pearl']:
        f = open('snapshot_{}.pkl'.format(name), 'rb')
        trajectories = pickle.load(f)
        if idx == 180:
            num_trajs = len(trajectories['task180'])
        if name == 'mpc':
            adapted_before = trajectories['task{}'.format(idx)][0]['observations']
            adapted_colh_before = trajectories['task{}'.format(idx)][0]['collisions_human']
            adapted_colt_before = trajectories['task{}'.format(idx)][0]['collisions_table']
            adapted_after = adapted_before
            adapted_colh_after = adapted_colh_before
            adapted_colt_after = adapted_colt_before
        else:
            adapted_before = trajectories['task{}'.format(idx)][0]['observations']
            adapted_colh_before = trajectories['task{}'.format(idx)][0]['collisions_human']
            adapted_colt_before = trajectories['task{}'.format(idx)][0]['collisions_table']
            adapted_after = trajectories['task{}'.format(idx)][num_trajs-1]['observations']
            adapted_colh_after = trajectories['task{}'.format(idx)][num_trajs-1]['collisions_human']
            adapted_colt_after = trajectories['task{}'.format(idx)][num_trajs-1]['collisions_table']
        if name == 'pearl':
            for i in range(num_people):
                x_human = 5. * np.array(adapted_before[:, 3 + 2 * i])
                y_human = 5. * np.array(adapted_before[:, 3 + 2 * i + 1])
                for t in range(ep_len):
                    alpha = t * (alpha_max - alpha_min) / ep_len + alpha_min
                    obstacle = plt.Circle((x_human[t], y_human[t]),
                                          human_radii,
                                          color='tab:orange',
                                          alpha=alpha
                                          )
                    ax.add_artist(obstacle)

                # ax.plot(x_human, y_human, color='tab:red', linestyle='dashed')

        x_before = 5. * np.array(adapted_before)[:, 0]
        y_before = 5. * np.array(adapted_before)[:, 1]

        x_after = 5. * np.array(adapted_after)[:, 0]
        y_after = 5. * np.array(adapted_after)[:, 1]

        color = next(colors)
        label = next(labels)
        x_col_pts_before = [x_before[t] for t in range(ep_len) if (adapted_colh_before[t] + adapted_colt_before[t]) > 0 ]
        y_col_pts_before = [y_before[t] for t in range(ep_len) if (adapted_colh_before[t] + adapted_colt_before[t]) > 0 ]        

        x_col_pts_after = [x_after[t] for t in range(ep_len) if (adapted_colh_after[t] + adapted_colt_after[t]) > 0 ]
        y_col_pts_after = [y_after[t] for t in range(ep_len) if (adapted_colh_after[t] + adapted_colt_after[t]) > 0 ]        
        if name == 'pearl':
            linestyle = 'solid'
        elif name == 'mpc':
            linestyle = 'solid'
        elif name in [2, 5]:
            linestyle = 'solid'
        else:
            linestyle = 'solid'

        if name in ['pearl', 'mpc']:
            marker = 'D'
            markersize = 4
        elif name in [2, 5]:
            marker = 's'
            markersize = 4
        else:
            marker = 'o'
            markersize = 4

        if adapted:
            ax.plot(x_after, y_after, color=color, label=label, linestyle=linestyle, linewidth=1, marker=marker, markersize=markersize, zorder=1)
            ax.scatter(x_col_pts_after, y_col_pts_after, facecolor='white', edgecolor=color, marker='*', s=240, zorder=2)
        else:
            ax.plot(x_before, y_before, color=color, label=label, linestyle=linestyle, linewidth=1, marker=marker, markersize=markersize, zorder=1)
            ax.scatter(x_col_pts_before, y_col_pts_before, facecolor='white', edgecolor=color, marker='*', s=240, zorder=2)
    ax.set_xlabel(r'$\mathrm{x}$', fontsize=16)
    ax.set_ylabel(r'$\mathrm{y}$', fontsize=16)
    """
    leg = ax.legend(ncol=6, fontsize=24, framealpha=0.0, bbox_to_anchor=(1.25, -1.25), handlelength=3)
    
    for legobj in leg.legendHandles:
        legobj.set_linewidth(7)
        legobj._legmarker.set_markersize(16)
    if idx == 180:
        export_legend(leg)
    """
    plt.scatter(init_pos[0], init_pos[1], color='black', marker='s', s=80, zorder=3)
    plt.annotate('Start', (init_pos[0] + 0.5, init_pos[1] + 0.1))
    plt.scatter(goal_pos[0], goal_pos[1], color='black', marker='s', s=80, zorder=3)
    plt.annotate('Goal', (goal_pos[0], goal_pos[1] - 0.5))
    fig.tight_layout()
    if adapted:
        filename = os.path.join(dirname, 'pearl{}_after.pdf'.format(idx))
        fig.savefig(filename, dpi=360)
    else:
        filename = os.path.join(dirname, 'pearl{}_before.pdf'.format(idx))
        fig.savefig(filename, dpi=360)
    plt.close()


adapted = True

for idx in range(180, 205):
    colors = iter(['tab:brown'])
    labels = iter(['PEARL'])
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.set_aspect('equal')


    table_pos = tables['task{}'.format(idx)]
    for i in range(num_tables):
        x_table = table_pos[2 * i]
        y_table = table_pos[2 * i + 1]
        obstacle = plt.Circle((x_table, y_table),
                              table_radii,
                              color='tab:blue'
                              )
        ax.add_artist(obstacle)
    ax.grid(True)
    ax.set_xlim(-5., 5.)
    ax.set_ylim(-5., 5.)

    for name in ['pearl']:
        f = open('snapshot_{}.pkl'.format(name), 'rb')
        trajectories = pickle.load(f)
        if idx == 180:
            num_trajs = len(trajectories['task180'])

        adapted_before = trajectories['task{}'.format(idx)][0]['observations']
        adapted_colh_before = trajectories['task{}'.format(idx)][0]['collisions_human']
        adapted_colt_before = trajectories['task{}'.format(idx)][0]['collisions_table']
        adapted_after = trajectories['task{}'.format(idx)][num_trajs-1]['observations']
        adapted_colh_after = trajectories['task{}'.format(idx)][num_trajs-1]['collisions_human']
        adapted_colt_after = trajectories['task{}'.format(idx)][num_trajs-1]['collisions_table']
        if name == 'pearl':
            for i in range(num_people):
                x_human = 5. * np.array(adapted_before[:, 3 + 2 * i])
                y_human = 5. * np.array(adapted_before[:, 3 + 2 * i + 1])
                for t in range(ep_len):
                    alpha = t * (alpha_max - alpha_min) / ep_len + alpha_min
                    obstacle = plt.Circle((x_human[t], y_human[t]),
                                          human_radii,
                                          color='tab:orange',
                                          alpha=alpha
                                          )
                    ax.add_artist(obstacle)

                # ax.plot(x_human, y_human, color='tab:red', linestyle='dashed')

        x_before = 5. * np.array(adapted_before)[:, 0]
        y_before = 5. * np.array(adapted_before)[:, 1]

        x_after = 5. * np.array(adapted_after)[:, 0]
        y_after = 5. * np.array(adapted_after)[:, 1]

        color = next(colors)
        label = next(labels)
        x_col_pts_before = [x_before[t] for t in range(ep_len) if (adapted_colh_before[t] + adapted_colt_before[t]) > 0 ]
        y_col_pts_before = [y_before[t] for t in range(ep_len) if (adapted_colh_before[t] + adapted_colt_before[t]) > 0 ]        

        x_col_pts_after = [x_after[t] for t in range(ep_len) if (adapted_colh_after[t] + adapted_colt_after[t]) > 0 ]
        y_col_pts_after = [y_after[t] for t in range(ep_len) if (adapted_colh_after[t] + adapted_colt_after[t]) > 0 ]        
        if name == 'pearl':
            linestyle = 'solid'

        if name in ['pearl', 'mpc']:
            marker = 'D'
            markersize = 4

        if adapted:
            ax.plot(x_after, y_after, color=color, label=label, linestyle=linestyle, linewidth=1, marker=marker, markersize=markersize, zorder=1)
            ax.scatter(x_col_pts_after, y_col_pts_after, facecolor='white', edgecolor=color, marker='*', s=240, zorder=2)
        else:
            ax.plot(x_before, y_before, color=color, label=label, linestyle=linestyle, linewidth=1, marker=marker, markersize=markersize, zorder=1)
            ax.scatter(x_col_pts_before, y_col_pts_before, facecolor='white', edgecolor=color, marker='*', s=240, zorder=2)
    ax.set_xlabel(r'$\mathrm{x}$', fontsize=16)
    ax.set_ylabel(r'$\mathrm{y}$', fontsize=16)
    """
    leg = ax.legend(ncol=6, fontsize=24, framealpha=0.0, bbox_to_anchor=(1.25, -1.25), handlelength=3)
    
    for legobj in leg.legendHandles:
        legobj.set_linewidth(7)
        legobj._legmarker.set_markersize(16)
    if idx == 180:
        export_legend(leg)
    """
    plt.scatter(init_pos[0], init_pos[1], color='black', marker='s', s=80, zorder=3)
    plt.annotate('Start', (init_pos[0] + 0.5, init_pos[1] + 0.1))
    plt.scatter(goal_pos[0], goal_pos[1], color='black', marker='s', s=80, zorder=3)
    plt.annotate('Goal', (goal_pos[0], goal_pos[1] - 0.5))
    fig.tight_layout()
    if adapted:
        filename = os.path.join(dirname, 'pearl{}_after.pdf'.format(idx))
        fig.savefig(filename, dpi=360)
    else:
        filename = os.path.join(dirname, 'pearl{}_before.pdf'.format(idx))
        fig.savefig(filename, dpi=360)
    plt.close()
