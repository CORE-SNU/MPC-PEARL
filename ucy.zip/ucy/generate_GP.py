import os
import shutil
import os.path as osp
import pickle
import json
import numpy as np
import click
import torch
import csv
import random
import time

from rlkit.envs import ENVS
from rlkit.envs.wrappers import NormalizedBoxEnv
from rlkit.torch.sac.policies import TanhGaussianPolicy
from rlkit.torch.networks import FlattenMlp, MlpEncoder, RecurrentEncoder
from rlkit.torch.sac.agent import PEARLAgent
from configs.default import default_config
from launch_experiment import deep_update_dict
from rlkit.torch.sac.policies import MakeDeterministic
from rlkit.samplers.util import rollout
from rlkit.torch.sac.sac import PEARLSoftActorCritic


from gp_mpc import InitGP, GP


def sim_policy(variant, path_to_exp, num_trajs=1, deterministic=False, save_video=False):
    '''
    simulate a trained policy adapting to a new task
    optionally save videos of the trajectories - requires ffmpeg

    :variant: experiment configuration dict
    :path_to_exp: path to exp folder
    :num_trajs: number of trajectories to simulate per task (default 1)
    :deterministic: if the policy is deterministic (default stochastic)
    :save_video: whether to generate and save a video (default False)
    '''

    # create multi-task environment and sample tasks
    env = NormalizedBoxEnv(ENVS[variant['env_name']](**variant['env_params']))
    tasks = env.get_all_task_idx()
    obs_dim = int(np.prod(env.observation_space.shape))
    action_dim = int(np.prod(env.action_space.shape))
    eval_tasks=list(tasks)
    random.shuffle(eval_tasks)
    print('testing on {} test tasks, {} trajectories each'.format(len(eval_tasks), num_trajs))

    # instantiate networks
    latent_dim = variant['latent_size']
    context_encoder = latent_dim * 2 if variant['algo_params']['use_information_bottleneck'] else latent_dim
    reward_dim = 1
    net_size = variant['net_size']
    recurrent = variant['algo_params']['recurrent']
    encoder_model = RecurrentEncoder if recurrent else MlpEncoder

    variant['algo_params']['use_MPC'] = False

    qf1 = FlattenMlp(
        hidden_sizes=[net_size, net_size, net_size],
        input_size=obs_dim + action_dim + latent_dim,
        output_size=1,
    )
    qf2 = FlattenMlp(
        hidden_sizes=[net_size, net_size, net_size],
        input_size=obs_dim + action_dim + latent_dim,
        output_size=1,
    )
    vf = FlattenMlp(
        hidden_sizes=[net_size, net_size, net_size],
        input_size=obs_dim + latent_dim,
        output_size=1,
    )
    context_encoder = encoder_model(
        hidden_sizes=[200, 200, 200],
        input_size=obs_dim + action_dim + reward_dim,
        output_size=context_encoder,
    )
    policy = TanhGaussianPolicy(
        hidden_sizes=[net_size, net_size, net_size],
        obs_dim=obs_dim + latent_dim,
        latent_dim=latent_dim,
        action_dim=action_dim,
    )
    agent = PEARLAgent(
        latent_dim,
        context_encoder,
        policy,
        **variant['algo_params']
    )
    algorithm = PEARLSoftActorCritic(
        env=env,
        train_tasks=list(tasks[:variant['n_train_tasks']]),
        eval_tasks=list(tasks[-variant['n_eval_tasks']:]),
        nets=[agent, qf1, qf2, vf],
        latent_dim=latent_dim,
        **variant['algo_params']
    )
    
    # deterministic eval
    if deterministic:
        agent = MakeDeterministic(agent)

    # load trained weights (otherwise simulate random policy)
    context_encoder.load_state_dict(torch.load(os.path.join(path_to_exp, 'context_encoder.pth')))
    policy.load_state_dict(torch.load(os.path.join(path_to_exp, 'policy.pth')))

    # loop through tasks collecting rollouts
    all_rets = []
    video_frames = []
    algorithm.pretrain()
    count = 0

    # GP to save
    task_good = []
    gp_list = []

    for task in eval_tasks:
        print('Saved %d tasks'%(count))
        print(task_good)
        if count >= 400:
            print('Saved!')
            break
        env.reset_task(task)
        agent.clear_z()
        paths = []
        gp_human = None
        start = time.time()
        
        if variant['algo_params']['use_MPC']:
            env.eps = 0
        
        path = rollout(env,
                       agent,
                       max_path_length=variant['algo_params']['max_path_length'],
                       accum_context=True,
                       animated=False,
                       use_MPC=variant['algo_params']['use_MPC'],
                       gp_human=gp_human,
                       test=False,
                       mpc_solver=algorithm.mpc,
                       save_frames=save_video
                       )
        paths.append(path)
        
        # Train GPMPC at first traj, where z is initialized
        gp_human = path['gp_human']
        if gp_human is None:
            xlb = env.observation_space.low[2:]
            xub = env.observation_space.high[2:]
            solver_opts = {}
            solver_opts['expand'] = False
            X = path['observations']
            Y = path['next_observations']
            X = [x[2:] for x in X]
            Y = [y[2:] for y in Y]
            # To test!
            idx = random.sample(range(len(X)), 20)
            #idx = range(5,len(X))
            _idx = list(range(len(X)))
            for val in idx:
                for i, val_compare in enumerate(_idx):
                    if val == val_compare:
                        _idx.pop(i)

            X_test = [X[i] for i in idx]
            Y_test = [Y[i] for i in idx]
            X_train = [X[i] for i in _idx]
            Y_train = [Y[i] for i in _idx]
            
            #gp_human = GP(np.array(X_train), np.array(Y_train), xlb=xlb, xub=xub, optimizer_opts=solver_opts, normalize=False)
            try:
                gp_human = GP(np.array(X_train), np.array(Y_train), optimizer_opts=solver_opts, normalize=False)
                SMSE, MNLP = gp_human.validate(np.array(X_test), np.array(Y_test))    # Need validation?
                gp_human_dict = gp_human.give_dict()
                gp_list.append(gp_human_dict)
                task_good.append(task)
                print(task)
                count += 1

            except:
                gp_human = None
                print('GP error : cannot correctly estimate obstacle. Do not update GP')
        
        print('Elapsed time : %.4f'%(time.time()-start))
        print('')

    print(task_good)
    np.save('tasks_with_gp.npy',np.array(task_good))
    with open("gp_human.pickle", 'wb') as handle:
        # Save result from dict_statistics
        pickle.dump(gp_list, handle)


@click.command()
@click.argument('config', default=None)
@click.argument('path', default=None)
@click.option('--num_trajs', default=10)
@click.option('--deterministic', is_flag=True, default=False)
@click.option('--video', is_flag=True, default=False)
def main(config, path, num_trajs, deterministic, video):
    np.random.seed(666)
    variant = default_config
    if config:
        with open(osp.join(config)) as f:
            exp_params = json.load(f)
        variant = deep_update_dict(exp_params, variant)
    sim_policy(variant, path, num_trajs, deterministic, video)


if __name__ == "__main__":
    main()
