import numpy as np
from scipy.stats import gaussian_kde
import matplotlib.pyplot as plt
import seaborn
import pickle


names = ['pearl', 'eps2e-1', 'eps5e-1', 'eps8e-1', 'eps1e0']
num_trajs = 5
tasks = range(205, 405)

returns = {}

avg_returns = {name: {} for name in names}
std_returns = {name: {} for name in names}

for name in names:
    with open('./worst_case_analysis/{}_return.pickle'.format(name), 'rb') as handle:
        returns[name] = pickle.load(handle)
    for idx in tasks:
        # seed average
        avg_returns[name][idx] = np.mean(returns[name][idx], axis=0)
        std_returns[name][idx] = np.std(returns[name][idx], axis=0)

avg_returns_after_adaptations = {name: {idx: avg_returns[name][idx][-1] for idx in tasks} for name in names}

# ========================== plot ==========================
label = {
    'pearl': 'PEARL',
    'eps2e-1': r'$\epsilon=0.2$',
    'eps5e-1': r'$\epsilon=0.5$',
    'eps8e-1': r'$\epsilon=0.8$',
    'eps1e0': r'$\epsilon=1$',
}
color = {
    'pearl': 'tab:brown',
    'eps2e-1': 'tab:purple',
    'eps5e-1': 'tab:orange',
    'eps8e-1': 'tab:blue',
    'eps1e0': 'tab:red',



}

n_bins = 40

fig, ax = plt.subplots(figsize=(9, 6))
x = np.linspace(-1750., 250., 500)
for name in names:
    r = list(avg_returns_after_adaptations[name].values())
    """
    density = gaussian_kde(r)
    density.covariance_factor = lambda: .25
    density._compute_covariance()
    ax.plot(x, density(x), label=label[name], color=color[name])
    """
    seaborn.distplot(r, hist=True, kde=True, color=color[name], label=label[name])

    """
    ax.hist(r,
            bins=n_bins,
            label=label[name],
            color=color[name],
            alpha=0.8
            )
    """

ax.set_xlabel('Return', fontsize=18)
ax.set_ylabel('Density', fontsize=18)
ax.grid(True)
ax.legend(fontsize=18)
fig.tight_layout()
fig.savefig('./worst_case_analysis/histogram.pdf', dpi=1200)
